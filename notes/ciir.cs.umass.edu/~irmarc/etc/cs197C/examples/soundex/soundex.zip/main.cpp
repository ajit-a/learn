#include <iostream>
#include <string>
#include "soundex.h"

using namespace std;

int main(int argc, char **argv) {
  
  if (argc < 2) {
    cout << "Need an argument to convert" << endl;
  }

  string output = soundex(argv[1]);
  cout << "Soundex string is: " << output << endl;
}
