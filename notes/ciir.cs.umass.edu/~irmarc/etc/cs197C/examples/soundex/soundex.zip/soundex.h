#ifndef SOUNDEX_H
#define SOUNDEX_H

#include <string>

using namespace std;

string soundex(char *str);

#endif
