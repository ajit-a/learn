#include "soundex.h"
#include <string>

using namespace std;

string soundex(char* str) {
  
  char lookup[] = {'0','1','2','3','0','1','2','0','0','2','2','4','5','5','0','1','0','6','2','3','0','1','0','2','0','2', };
  int n=4;
  static  char buff[10];
  register char *s, *t = &buff[0];
  char c, l;
  
  for (s = str; ((c = *s) != '\0') && t < &buff[n]; s++) {
    if (!isascii(c)) continue;
    if (!isalpha(c)) continue;
    c = toupper(c);
    if (t == &buff[0]) {
      l = *t++ = c;
      continue;
    }
    c = lookup[c-'A'];
    if (c != '0' && c != l) l = *t++ = c;
  }
  while (t < &buff[n])
    *t++ = '0';
  *t = '\0';
  return(&buff[0]);
}

