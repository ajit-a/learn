#include <iostream>
#include <string>
#include <vector>


using namespace std;


class AlienDNA {
private:
  string genome;

public:
  string getGenome();
  
}
