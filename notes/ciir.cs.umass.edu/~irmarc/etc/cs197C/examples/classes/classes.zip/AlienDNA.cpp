#include "AlienDNA.hpp"
#include <string>
#include <iostream>
#include <vector>
#include <cstdlib>

string AlienDNA::generateRandomString(int n) {
  string str;
  char c;
  for (int i = 0; i < n; i++) {
    switch (rand() % 3) {
    case 0: {
      // generate a capital alpha character
      c = (rand() % 26) + 'A';
    }; break;
    case 1: {
      // lowercase alpha
      c = (rand() % 26) + 'a';
    }; break;
    case 2:{
      // generate a digit
      c = (rand() % 10) + '0';
    }; break;
    }
    str += c;
  }
  return str;
}

AlienDNA::AlienDNA(string n, string dna) {
  name = n;
  genome = dna;
  weight = 2;
}

AlienDNA::AlienDNA(string n, int l) {    
  name = n;
  genome = generateRandomString(l);
  weight = 0;
}

// Simulates mating between two alien blobs
AlienDNA AlienDNA::operator*(AlienDNA other) {
  int pos;
  string otherDNA = other.getGenome();
  int newLength = (rand() % (otherDNA.size() + genome.size()));
  newLength = (newLength == 0) ? 1 : newLength;
  string newGenome;
  for (int i = 0; i < newLength; i++) {
    if (rand() % 2) {
      pos = rand() % genome.size();
      newGenome += genome[pos];
    } else {
      pos = rand() % otherDNA.size();
      newGenome += otherDNA[pos];
    }
  }
  AlienDNA baby("d'" + name, newGenome);
  
  // Some weight goes to the baby
  weight--;
  other.weight--; // <--- broken
  return baby;
}

AlienDNA AlienDNA::operator=(AlienDNA orig) {
  name = orig.getName();
  genome = orig.getGenome();
  weight = orig.getWeight();
}

bool AlienDNA::operator<(AlienDNA other) {
  return (weight < other.getWeight());
}

bool AlienDNA::operator>(AlienDNA other) {
  return (weight > other.getWeight());
}

bool AlienDNA::operator==(AlienDNA other) {
  return ((name == other.getName()) && 
	  (genome == other.getGenome()) && 
	  (weight == other.getWeight()));
}

bool AlienDNA::operator!=(AlienDNA other) {
  return !((*this) == other);
}


AlienDNA* const AlienDNA::operator+(Thing t) {
  cout << (*this) << " is absorbing " << t << "!" << endl;
  weight += t.getWeight();
  return this;
}

AlienDNA* const AlienDNA::operator+=(Thing t) {
  return ((*this) + t);
}

AlienDNA* const AlienDNA::operator<<(Thing t) {
  return ((*this) + t);
}

AlienDNA* const AlienDNA::operator()(vector<Thing> stuff) {
  for (vector<Thing>::iterator it = stuff.begin(); it != stuff.end(); it++) {
    (*this) += (*it);
  }
  return this;
}

// NOT a member, BUT a friend!
ostream &operator<<(ostream &stream, AlienDNA dna) {
  stream << "<" << dna.name << "," << dna.weight << ","  << dna.genome << ">";
  return stream;
}

// This one too!
ostream &operator<<(ostream &stream, Thing t) {
  stream << "(" << t.desc << "," << t.weight << ")";
  return stream;
}
