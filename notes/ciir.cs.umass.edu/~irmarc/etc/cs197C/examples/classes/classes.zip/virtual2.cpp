/**
 * Short example file to look at overriding in C++
 * Here, Z is not implementing the "sayHello" method, hence
 * cannot subclass X.
 */

#include <iostream>

using namespace std;

class X {
public:
  X() { cout << "X's ctor" << endl; }
  ~X() { cout << "X's dtor" << endl; }

  virtual void sayHello() = 0;
};

class Y : public X {
public:
  Y() { cout << "Y's ctor" << endl; } 
  ~Y() { cout << "Y's dtor" << endl; }

  void sayHello() {
    cout << "Y is saying hello!" << endl;
  }
};

class Z : public X {
public:
  Z() { cout << "Z's ctor" << endl; }
  ~Z() { cout << "Z's dtor" << endl; }
};


int main(int argc, char **argv) {
  Y *sub1 = new Y();
  Z *sub2 = new Z();

  sub2->sayHello();
  sub1->sayHello();

  delete sub1;
  delete sub2;
}
