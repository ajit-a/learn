#ifndef ALIENS
#define ALIENS

#include <iostream>
#include <string>
#include <vector>


using namespace std;

// STUB
class Thing;

class AlienDNA {
private:
  string genome;
  int weight;
  string name;
  string generateRandomString(int n);
public:
  
  // Makes a new random one of length n
  AlienDNA(string n, int l);
  AlienDNA(string n, string dna);

  // Produces the current genome
  string getGenome() { return genome; }
  
  // gets weight
  int getWeight() { return weight; }

  // name
  string getName() { return name; }

  // Mating operator
  AlienDNA operator*(AlienDNA mate);
  
  // Cloning operator
  AlienDNA operator=(AlienDNA orig);

  // Based on weight
  bool operator<(AlienDNA other);
  bool operator>(AlienDNA other);

  // Identical twins?
  bool operator==(AlienDNA other);
  bool operator!=(AlienDNA other);

  // Absorbing stuff
  AlienDNA* const operator+(Thing t);
  AlienDNA* const operator+=(Thing t);
  AlienDNA* const operator<<(Thing t);

  // Batch absorption!
  AlienDNA* const operator()(vector<Thing> stuff);

  // This is for printing out - aka an "inserter"
  friend ostream &operator<<(ostream &stream, AlienDNA dna);
};

class Thing {
private:
  int weight;
  string desc;
  //AlienDNA operator+(const AlienDNA ad) { return (ad + this); }

public:
  Thing(int i, string d) { 
    weight = i; desc = d; 
    cout << "Making thing: " << (*this) << endl;
  }
  ~Thing() {}

  int getWeight() { return weight; }
  string getDescription() { return desc; }

  // This is for printing out - aka an "inserter"
  friend ostream &operator<<(ostream &stream, Thing t);
};

#endif // ALIENS
