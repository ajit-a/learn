#include "AlienDNA.hpp"
#include <vector>
#include <string>
#include <sstream>

using namespace std;

int main(int argc, char **argv) {
  AlienDNA blob1("Donnie", 5);
  AlienDNA blob2("Marie", 10);

  cout << "Let's make some blobs..." << endl << endl;
  
  cout << "First:  " << blob1 << endl;
  cout << "Second: " << blob2 << endl;

  cout << endl << " and now some objects..." << endl << endl;

  Thing car(2000, "toyota");
  Thing couch(198, "futon");
  Thing food(5, "cheeseburger");

  blob1 << car;
  blob2 += couch;
  
  cout << blob1.getName() << " now weighs " << blob1.getWeight() << endl;
  cout << blob2.getName() << " now weighs " << blob2.getWeight() << endl;

  cout << endl << "Mating season: " << endl;

  AlienDNA blob3 = blob1 * blob2;
  
  cout << "Offspring: " << blob3 << endl;
  cout << blob1.getName() << " now weighs " << blob1.getWeight() << endl;
  cout << blob2.getName() << " now weighs " << blob2.getWeight() << endl;
  
  cout << endl << "Now let's eat stuff via a vector..." << endl << endl;
  vector<Thing> krispies;
  for (int i = 0; i < 5; i++) {
    ostringstream oss;
    oss << "rice krispie #" << i;
    Thing t(1, oss.str());
    krispies.push_back(t);
  }

  blob3(krispies);
  blob3 += food;
  cout << blob3.getName() << " now weighs " << blob3.getWeight() << endl;
}
