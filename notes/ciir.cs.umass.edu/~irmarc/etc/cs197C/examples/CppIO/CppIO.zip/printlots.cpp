#include <iostream>
#include <string>
#include <cstdlib> // character manipulation functions isupper and tolower
#include <cmath>
#include <vector>
#include <thread>
#include <future>

using namespace std;

// These are the functions we'll be defining under main
// In bigger programs these are in the header file

#define BUFSIZE 4196

void lcase(string &str);
void pi();
void echo();
void add();
void addr();
void help();

int main(int argc, char *argv[]) {
  
  string cmd = "help";

  while (cmd != "quit") {
    cout << "Please enter a command (help for details): ";
    cin.seekg(0, ios::end); // This skips any unextracted input from the cin stream
    cin >> cmd;
    lcase(cmd);
    if (cmd == "help") help();
    else if (cmd == "pi") pi();
    else if (cmd == "echo") echo();
    else if (cmd == "add") add();
    else if (cmd == "addr") addr();
    else if (cmd == "quit") break; // kinda hacky, but stops the fallthrough to error
    else {
      cout << "I don't understand the command '" << cmd << "'. Please try again." << endl;
    }
  }

  cout << "Goodbye!" << endl;
  return 0;
}

// Using an inline function w/ a reference passed here.
// Inlining is the C++ version of macros.
// References are implicit pointers - it looks concrete to you,
// but the compiler is really using the same object as before.
inline void lcase(string &str) {
  for (int i = 0; i < str.length(); i++) {
    str[i] = (isupper(str[i]) ? tolower(str[i]) : str[i]);
  }
}

void pi() {
  cout << "We're going to print the value of PI in fixed-point notation and scientific notation." << endl;
  cout << "That's less than 100 times (or in hex: " << hex << 100 << " or octal: " << oct << 100 << ")" << endl;
  cout << "PI is: " << M_PI << endl;
  cout << "In fixed-point it's: " << fixed << M_PI << endl;
  cout << "In scientific notation it's : " << scientific << M_PI << endl;
}

void echo() {
  char buffer[BUFSIZE];

  cout << "Type something in and I'll repeat it: ";
  cin.seekg(ios::end);
  cin.getline(buffer, BUFSIZE);
  cout << "You said: \"" << buffer << "\"" << endl;
}

void add() {
  double n1, n2;

  cout << "Please type in a number, hit enter, then another number, then enter again." << endl;
  cin >> n1;
  if (cin.fail()) {
    cout << "Couldn't read the first number. Cowardly backing out." << endl;
  } else {
    cin >> n2; 
    if (cin.fail()) {
      cout << "Couldn't read the second number. Cowardly backing out." << endl;
    } else {
      // Good to go
      double result = n1 + n2;
      cout << "The sum is: " << result << endl;
    }
  }
  
  // Just make sure it's ready for the next input
  cin.clear();
}

void addr() {
  vector<int> *v = new vector<int>();
  cout << "The address of the allocated memory is: " << hex << v << endl;
  delete v;
}

void help() {
  
  cout << " I understand the following limited commands:" << endl;
  cout << "\tPI or pi) Print out the constant PI a bunch of different ways." << endl;
  cout << "\techo) Echo back some input you enter." << endl;
  cout << "\tadd) Add two numbers and return the sum." << endl;
  cout << "\taddr) Allocate some random memory in the help, report the address of it, and delete it." << endl;
  cout << "\tquit) Quits." << endl;
}

