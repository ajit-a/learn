#include <functions.h>
#include <stdio.h>

int main(int argc, char *argv[]) {

  int i;
  int numbers[10000]; // We can hold up to 10K numbers to look at
  int len = read_numbers(argv[1], numbers);
  char *sentence = "I am not a very long sentence. That's a shame.";

  // Getting the average 
  double a = avg(len, numbers);
  
  // Now the variance
  double v = var(len, a, numbers);

  // Count periods
  int num_periods = count_char('.', sentence);

  // Make a copy
  char *newsent = copy_str(sentence);

  // Now print out a bunch of stuff
  printf("Looking at the following list of numbers:");
  for (i = 0; i < len; i++) { printf("%d ", numbers[i]); }
  printf("\n\nThe average is: %f, and the variance is: %f\n\n", a, v);
  
  // Now look at the sentence
  printf("Given sentence: %s\n", sentence);
  printf("The copy looks like: %s\n", newsent);
  printf("Number of times '.' appears: %d\n", num_periods);

  // Deallocate the copy - in C++ this is 'delete'
  free(newsent);

  return 0;
}
