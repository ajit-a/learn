#ifndef FUNCTIONS_H
#define FUNCTIONS_H

int read_numbers(char *filename, int buffer[]);

double avg(int len, int numbers[]);

double var(int len, double avg, int numbers[]);

int count_char(char c, char *str);

char *copy_str(char *str);

#endif // FUNCTIONS_H
