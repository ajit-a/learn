// We use bracket notation here to tell the compiler to
// look in the "default" locations for header files.
#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include <limits.h>
#include <string.h>

// The quote notation tells the compiler to look in the user-supplied
// locations for header files.
#include "functions.h"

// Reads numbers in from a file. The buffer NEEDS to have a enough room to support
// the numbers read in. Otherwise... bad things.
int read_numbers(char *filename, int buffer[]) {
  FILE *f = fopen(filename, "r");
  int i = 0;
  
  printf("reading in from file %s\n", filename);
  while (!feof(f)) {
    fscanf(f, "%d\n", &(buffer[i])); // <-- the "&(buffer[count])" reads as "the address of the ith element in buffer"
    printf("Read %d\n", buffer[i]); // There's an "fprintf" variant that prints to files...
    i++;
  }
  
  fclose(f);
  return i;
}

// Calculates the average of an array of numbers
double avg(int len, int numbers[]) {
  double total = 0.0;
  int i;

  printf("Getting average.\n");

  for (i = 0; i < len; i++) {
    total += numbers[i];
  }
  return (total / len);
}

// Calculates the variance of an array of numbers
double var(int len, double avg, int numbers[]) {
  double total = 0.0;
  int i;

  for (i = 0; i < len; i++) {
    double d = avg - numbers[i];
    total +=  (d*d);
  }
  return (total / len);
}

// Counts the number of times a character occurs in a given C-string
int count_char(char c, char *str) {
  int len = strlen(str);
  int i;
  int count = 0;

  for (i = 0; i < len; i++) {
    if (str[i] == c) count++;
  }

  return count;
}

// A quick and dirty version of the strcpy function supplied by string.h
char *copy_str(char *str) {
  int len = strlen(str);
  char *newstr = (char*) malloc(len+1);
  memcpy(newstr, str, len+1);
}
