/**
 * Small program to count the number of character occurrences in
 * an input file.
 *
 * Compile me with 'g++ -o <program name> count_words.cpp'
 *
 * Usage: ./<program name> <input filename>
 */


#include <map>
#include <fstream>
#include <iostream>

using namespace std;

int main(int argc, char *argv[]) {
  
  ifstream fp;
  map<char, int> counts;
  string line;

  if (argc < 2) {
    cout << "Please supply a filename." << endl;
    return -1;
  }

  /* Read in a file, line by line */
  fp.open(argv[1]);
  while (getline(fp, line)) {
    for (int i = 0; i < line.length(); i++) {
      char c = line[i];
      if (counts.find(c) == counts.end()) counts[c] = 0;
      counts[c]++;
    }
  }
  fp.close();

  /* Now read out the occurrences of all the characters from the file. */
  for (map<char, int>::iterator it = counts.begin(); it != counts.end(); it++) {
    char c = (*it).first;
    int count = (*it).second;
    cout << c << " : " << count << endl;
  }

  return 0;
}
