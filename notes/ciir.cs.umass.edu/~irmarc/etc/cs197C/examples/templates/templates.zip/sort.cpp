/**
 * Example file to copy, sort and perform binary search on vectors.
 *
 * Compile with: g++ -g -o sort sort.cpp
 */


#include <vector>
#include <algorithm>
#include <fstream>
#include <iostream>

using namespace std;

bool mycomp(int i, int j) { return (i<j); }

int main(int argc, char *argv[]) {
  
  vector<int> myvec;

  /* Add items to the vector */
  for (int i = 20; i > -1; i--) {
    myvec.push_back(i);
  }

  /* Allocate copy vector */
  vector<int> copyvec(myvec.size());
  
  /* Copy */
  copy(myvec.begin(), myvec.end(), copyvec.begin());

  /* Sort first vector */
  sort(myvec.begin(), myvec.end(), mycomp);

  /* Print some results */
  vector<int>::iterator it;
  cout << "Original order: ";
  for (it = copyvec.begin(); it != copyvec.end(); it++) {
    cout << (*it) << " ";
  }
  cout << endl;

  cout << "Sorted order: ";
  for (it = myvec.begin(); it != myvec.end(); it++) {
    cout << (*it) << " ";
  }
  cout << endl;

  cout << "Searching for 18: " << endl;
  if (binary_search(myvec.begin(), myvec.end(), 18)) {
    cout << "Found it!" << endl;
  } else {
    cout << "no dice" << endl;
  }


  cout << "Searching for 47: " << endl;
  if (binary_search(myvec.begin(), myvec.end(), 47)) {
    cout << "Found it!" << endl;
  } else {
    cout << "no dice" << endl;
  }

  /* Time to make a mess! */
  vector<int> mistake(2);  
  
  copy(copyvec.begin(), copyvec.end(), mistake.begin());

  cout << "Copied ok" << endl;

  return 0;
}
