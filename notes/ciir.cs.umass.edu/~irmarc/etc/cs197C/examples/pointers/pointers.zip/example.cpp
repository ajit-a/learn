#include <cstdio>
#include <iostream>

int main(int argc, char **argv) {
  int m = 44;
  int *p = &m;
  int &r = m;
  int n = (*p)++;
  int *q = p - 1;
  r = *(--p) + 1;
  ++*q;

  printf("m=%d\n", m);
  printf("n=%d\n", n);
  std::cout << "&m=" << std::ios_base::hex << (&m) << std::endl;
  printf("*p=%d\n", (*p));
  std::cout << "r=" << r << std::endl;
  std::cout << "*q=" << (*q) << std::endl;

}
