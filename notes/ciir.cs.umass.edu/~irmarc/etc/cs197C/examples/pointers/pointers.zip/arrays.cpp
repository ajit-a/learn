/**
 * Simple file showing how arrays are manipulated
 * in C/C++
 *
 * Build me from the command line with: g++ -o arrays arrays.cpp
 */
#include <iostream>

using namespace std;


int main(int argc, char *argv[]) {

  // Stack array
  int nums[12];
  int *sp;

  for (int i = 0; i < 12; i++) {
    nums[i] = i;
  }

  
  cout << "Address of array start is: " << hex << nums << endl;
  cout << "sp starts out pointing to: " << hex << sp << endl;

  sp = nums;
  
  cout << "After setting, points to : " << hex << sp << endl << endl;
  
  cout << "The third element is " << nums[2] << " at address " << hex << &(nums[2]) << endl;
  cout << "You get the same thing doing it like this : " << *(sp+2) << " at address " << hex << (sp+2) << endl << endl;

  cout << "sp's address is " << hex << &(sp) << endl;
  cout << "What's creepy is so is nums[12]: " << hex << &(nums[12]) << endl;
  cout << "Even though it wasn't allocated on the stack!" << endl;

  cout << "So that means &(sp)-1 is the address " << hex << ((&sp)-1) << " with a value of " << dec << *((int*) ((&sp)-1)) << endl;
  cout << "Huh, that's the value of nums[10] (" << hex << &(nums[10]) << "). Why is that? " << endl;
  
  return 0;
}
