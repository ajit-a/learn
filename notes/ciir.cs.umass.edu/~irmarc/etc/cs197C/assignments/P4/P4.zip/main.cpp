#include "RedBlackTree.h"
#include <iostream>
#include <string>

using namespace std;

struct comp {
  bool operator() (const int &a, const int &b) const { return (a<b); }
};

int main(int argc, char *argv[]) {

  RedBlackTree<int, string, comp > *tree = new RedBlackTree<int, string, comp >();  
  tree->insert(1, "abc");
  tree->insert(2, "efq");
  tree->insert(3, "you");
  pair<int, string> *succ = tree->successor(1);
  cout << "Successor to 1 is: <" << succ->first << "," << succ->second << ">" << endl;
  tree->remove(3);
  
  delete tree;
}
