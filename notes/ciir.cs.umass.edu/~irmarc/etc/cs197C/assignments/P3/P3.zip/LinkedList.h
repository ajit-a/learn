#ifndef LINKED_LIST_CS197
#define LINKED_LIST_CS197

#include <cassert>

template<typename T>
class LinkedList {
private:
  class iterator {
    void operator++() const {
      // Does nothing right now
    }

    // Need to add data structures internal to the iterator here
  };

  // This class is basically complete. You shouldn't need to modify it.
  class Node {
  public:
    Node() { next = NULL; prev = NULL; }
    ~Node() {}
  public :
    Node *next;
    Node *prev;
    T data;
  };

  // Add internal strcutures for the list here

public:
  LinkedList();
  ~LinkedList();
  
  // methods -- note that the return values are of type T. Don't return a Node!
  void append(T item);
  T get(int idx);
  void insert(int idx, T item);
  void map(T (*pf)(T item));
  T remove(int index);
  int size();
  void unshift(T item);

  // Iterator methods - not very interesting right now

  // These need to return new iterators to the beginning, and AFTER the
  // end of, the sequence, respectively.
  const iterator begin() {
    return NULL;
  }

  const iterator end() {
    return NULL;
  }
};

// This returns a new, empty Linked List.
template <typename T>
LinkedList<T>::LinkedList() {
}

// Deletes the Linked List. It's not your job to call delete on the
// T item directly because you don't know what it is, but you are still responsible
// for any internal data strcutures you may have allocated.
template <typename T>
LinkedList<T>::~LinkedList() {
}

// Adds an item to the end of the sequence (after the tail).
// If the list is empty, then the appended item becomes the head AND the tail.
template <typename T>
void LinkedList<T>::append(T item) {
}

// Returns the item at position idx (0 returns the head). 
// You should perform a range check before servicing the request.
template <typename T>
T LinkedList<T>::get(int idx) {
  return NULL;
}

// Inserts an item at position idx. If idx is off the end of the sequence,
// it should just append to the end of the sequence. A negative index number
// results in an unshift.
template <typename T>
void LinkedList<T>::insert(int idx, T item) {
}

// Executes the provided function pointer over all
// elements in the sequence. Each item should be modified in place.
template <typename T>
void LinkedList<T>::map(T (*pf)(T item)) {
}

// Removes the item at position 'index'. The removed item should be
// returned.  
// A range check should be performed before servicing the request,
// therefore this method always returns a value.
template <typename T>
T LinkedList<T>::remove(int index) {
  return NULL;
}

// Returns the number of items in the sequence. This should
// complete in constant time.
template <typename T>
int LinkedList<T>::size() {
  return 0;
}

// Behaves like append, but inserts the item at the front of the sequence.
// Therefore the unshifted item becomes the new head of the sequence.
template <typename T>
void LinkedList<T>::unshift(T item) {
}

#endif
