#include "Lexicon.h"
#include <string>
#include <ostream>

// Some of the methods have default values to allow the code to
// compile, you are expected to replace these values with actual
// implementations.

using namespace std;

Lexicon::Lexicon(string &filename) {
}

Lexicon::~Lexicon() {
}

int Lexicon::count() {
  return 0;
}

int Lexicon::count(string &token) {
  return 0;
}

bool Lexicon::contains(string &token) {
  return false;
}

void Lexicon::increment(string &token) {
}

void Lexicon::increment(string &token, int n) {
}

void Lexicon::remove(string &token) {
}

void Lexicon::printLexicographically(ostream &out) {
}

void Lexicon::printCardinally(ostream &out) {
}


// Extra Credit - you do not need to modify this, but you can
// for extra credit.
double Lexicon::distanceFrom(Lexicon &other, double (*scoringFunction)(int count1, int total1, int count2, int total2)) {
  return 0.0;
}
