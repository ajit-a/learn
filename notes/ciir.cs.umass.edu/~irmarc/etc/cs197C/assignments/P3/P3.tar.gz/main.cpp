#include "Lexicon.h"
#include "StackCalculator.h"
#include "LinkedList.h"
#include <string>
#include <iostream>

using namespace std;

void usage() {
  cout << "Usage should go here." << endl;
}

// This is just to test your code - provide your own tests to convince
// yourself the code works.
int main(int argc, char *argv[]) {

  if (argc < 2) {
    usage();
    return 0;
  }
  
  // Wrap the second argument in a string
  string cmd(argv[1]);

  if (cmd == "lexicon") {
    // Do lexicon stuff here
  } else if (cmd == "stackcalc") {
    // Do stack calculator here
  } else if (cmd == "linkedlist") {
    // Do linked list stuff here
  } else {
    cout << "Command '" << cmd << "' unrecognized." << endl;
    usage();
  }

  return 0;
}
