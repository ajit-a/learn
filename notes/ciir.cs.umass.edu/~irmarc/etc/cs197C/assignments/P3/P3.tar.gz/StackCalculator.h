#ifndef CS197C_STACKCALC
#define CS197C_STACKCALC

class StackCalculator {

 public:
  
  // Constructs a new stack calculator
  StackCalculator();

  // Destroys the stack calculator
  // Don't forget to free any internally allocated data structures!
  ~StackCalculator();

  // You implement the methods you need to make the StackCalculator class
  // work as specified.

};

#endif
