#ifndef LINKED_LIST_CS197
#define LINKED_LIST_CS197

#include <cassert>
#include <iostream>

class LinkedList {
private:
  class iterator {
    void operator++() const {
      // Does nothing right now
    }

    // Need to add data structures internal to the iterator here
  };

  // This class is basically complete. You shouldn't need to modify it.
  class Node {
  public:
    Node() { next = NULL; prev = NULL; }
    ~Node() {}
  public :
    Node *next;
    Node *prev;
    int data;
  };

  // Add internal strcutures for the list here

public:
  // This returns a new, empty Linked List.
  LinkedList();

  // Deletes the Linked List. You are responsible for deleting
  // for any internal data strcutures you may have allocated.
  ~LinkedList();
  
  // Adds an item to the end of the sequence (after the tail).
  // If the list is empty, then the appended item becomes the head AND the tail.
  void append(int item);

  // Returns the item at position idx (0 returns the head). 
  // You should perform a range check before servicing the request.
  int get(int idx);

  // Inserts an item at position idx. If idx is off the end of the sequence,
  // it should just append to the end of the sequence. A negative index number
  // results in an unshift.
  void insert(int idx, int item);

  // Executes the provided function pointer over all
  // elements in the sequence. Each item should be modified in place.
  void map(int (*pf)(int item));

  // Removes the item at position 'index'. The removed item should be
  // returned. A range check should be performed before servicing the request,
  // therefore this method always returns a value. (If the check fails,
  // the assertion failure won't let this method finish).
  int remove(int index);

  // Returns the number of items in the sequence. This should
  // complete in constant time.
  int size();

  // Behaves like append, but inserts the item at the front of the sequence.
  // Therefore the unshifted item becomes the new head of the sequence.
  void unshift(int item);

  // Prints the list to stdout - one item per line
  void print();


  // Iterator methods - not very interesting right now

  // These need to return new iterators to the beginning, and AFTER the
  // end of, the sequence, respectively.
  const iterator begin() {
    return NULL;
  }

  const iterator end() {
    return NULL;
  }
};

#endif
