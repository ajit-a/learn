#include "LinkedList.h"
#include <iostream>

using namespace std;

int square (int x) { return (x*x); }

int main(int argc, char *argv[]) {

  LinkedList *list = new LinkedList();


  cout << "Starting size is: " << list->size() << endl;

  // Append some numbers
  for (int i = 0; i < 100; i++) {
    list->append(i);
  }

  // Put something on the front
  list->unshift(-9);
  
  // Size should be 101
  cout << "Size is : " << list->size() << endl;

  // Now remove 86
  int item = list->remove(87);
  cout << "Removed : " << item << endl;

  // Insert -1 in that place
  list->insert(87, -1);

  // Map all values by squaring them
  list->map(square);
  
  // Just add another number because
  list->insert(1, 12);

  // Now print them out -- ideally this would be an iterator
  for (int i = 0; i < list->size(); i++) {
    int item = list->get(i);
    cout << "Item at " << i << " " << item << endl;
  }

  // Now use the iterator to do the same thing
  for (LinkedList::iterator it = list->begin(); it != list->end(); it++) {
    cout << "Iterated item: " << *it << endl;
  }
  
  // We don't need an item-wise delete b/c the type in the list is primitive
  delete list;
}
