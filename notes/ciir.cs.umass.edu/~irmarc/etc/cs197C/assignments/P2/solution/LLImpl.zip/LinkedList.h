#ifndef LINKED_LIST_CS197
#define LINKED_LIST_CS197

#include <cassert>
#include <cstdlib>

class LinkedList {
private:
  // This class is basically complete. You shouldn't need to modify it.
  class Node {
  public:
    Node() { next = NULL; prev = NULL; }
    ~Node() {}

    Node *next;
    Node *prev;
    int data;
  };

  // Add internal strcutures for the list here
  int length;
  Node *head;
  Node *tail;

public:
  // Internal iterator class
  class iterator {
  private:
    Node *current;
  public:
    iterator(Node *start) { current = start; }
    ~iterator() { current = NULL; }

    public:
    int operator*() const {
      if (current == NULL) return NULL;
      return (current->data);
    }

    iterator& operator++() {
      if (current != NULL) current = current->next;
    }

    iterator& operator++(int) {
      if (current != NULL) current = current->next;
    }

    iterator& operator--() {
      if (current != NULL) current = current->prev;
    }

    iterator& operator--(int) {
      if (current != NULL) current = current->prev;
    }

    bool operator==(const iterator &other) const {
      return (current == other.current);
    }

    bool operator!=(const iterator &other) const {
      return (current != other.current);
    }
  };

  // Iterator methods - not very interesting right now

  // These need to return new iterators to the beginning, and AFTER the
  // end of, the sequence, respectively.
  const iterator begin() {
    return iterator(head);
  }

  const iterator end() {
    return iterator(NULL);
  }

 public:

  // This returns a new, empty Linked List.
  LinkedList();

  // Deletes the Linked List. It's not your job to call delete on the
  // T item directly because you don't know what it is, but you are still responsible
  // for any internal data strcutures you may have allocated.
  ~LinkedList();

  // Adds an item to the end of the sequence (after the tail).
  // If the list is empty, then the appended item becomes the head AND the tail.
  void append(int item);

  // Returns the item at position idx (0 returns the head). 
  // You should perform a range check before servicing the request.
  int get(int idx);

  // Inserts an item at position idx. If idx is off the end of the sequence,
  // it should just append to the end of the sequence. A negative index number
  // results in an unshift.
  void insert(int idx, int item);

  // Executes the provided function pointer over all
  // elements in the sequence. Each item should be modified in place.
  void map(int (*pf)(int item));

  // Removes the item at position 'index'. The removed item should be
  // returned.  
  // A range check should be performed before servicing the request,
  // therefore this method always returns a value.
  int remove(int index);

  // Returns the number of items in the sequence. This should
  // complete in constant time.
  int size();

  // Behaves like append, but inserts the item at the front of the sequence.
  // Therefore the unshifted item becomes the new head of the sequence.
  void unshift(int item);

  // Prints the list to stdout - one item per line
  void print();
};
#endif
