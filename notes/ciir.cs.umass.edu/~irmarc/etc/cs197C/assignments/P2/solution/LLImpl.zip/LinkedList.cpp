#include "LinkedList.h"
#include <cassert>
#include <iostream>

// This returns a new, empty Linked List.
LinkedList::LinkedList() {
  head = tail = NULL;
  length = 0;
}

LinkedList::~LinkedList() {
  Node *prev;
  while (head != NULL) {
    prev = head;
    head = prev->next;
    delete prev;
  }
}
  
void LinkedList::append(int item) {
  Node *newNode = new Node();
  newNode->data = item;

  if (length == 0) {
    head = newNode;
    tail = newNode;
  } else {
    tail->next = newNode;
    newNode->prev = tail;
    tail = newNode;
  }
  length++;
}

int LinkedList::get(int idx) {
  assert(idx >= 0 && idx < length);
  Node *current = head;
  for (int i = 0; i < idx; i++) {
    current = current->next;
  }
  return (current->data);
}

// Inserts an item at position idx. If idx is off the end of the sequence,
// it should just append to the end of the sequence. A non-positive index number
// results in an unshift.
void LinkedList::insert(int idx, int item) {
  if (idx <= 0) {
    unshift(item);
    return;
  }

  if (length == 0) {
    append(item);
    return;
  }

  // If we're here, it's legitimately in the middle of the list.
  Node *current = head;
  for (int i = 0; i < idx && current->next != NULL; i++) current = current->next;
  
  // Now at the right place
  Node *newItem = new Node();
  newItem->data = item;
  
  // Fix prior ptr
  newItem->next = current;
  newItem->prev = current->prev;
  current->prev = newItem;
  Node *prev = newItem->prev;
  if (prev != NULL) prev->next = newItem;
  length++;
}

// Executes the provided function pointer over all
// elements in the sequence. Each item should be modified in place.
void LinkedList::map(int (*pf)(int item)) {
  if (length == 0) return;
  Node *current = head;
  do {
    current->data = (pf(current->data));
    current = current->next;
  } while (current->next != NULL);
}

// Removes the item at position 'index'. The removed item should be
// returned. A range check should be performed before servicing the request,
// therefore this method always returns a value. (If the check fails,
// the assertion failure won't let this method finish).
int LinkedList::remove(int index) {
  assert(index >= 0 && index < length);
  
  Node *found = NULL;
  if (index == 0) {
    found = head;
    head = head->next;    
  } else {
    Node *current, *prev;
    current = head;
    for (int i = 0; i < index; i++) {
      prev = current;
      current = current->next;
    }
    found = current;
    // remove it
    prev->next = current->next;
    Node *next = prev->next;
    next->prev = prev;
  }
  found->next = NULL;
  found->prev = NULL;
  int item = found->data;
  delete found;
  length--;
  return item;
}

// Returns the number of items in the sequence. This should
// complete in constant time.
int LinkedList::size() { return length; }

// Behaves like append, but inserts the item at the front of the sequence.
// Therefore the unshifted item becomes the new head of the sequence.
void LinkedList::unshift(int item) {
  Node *newItem = new Node();
  newItem->data = item;
  if (head == NULL) {
    head = newItem;
    tail = newItem;
  } else {
    head->prev = newItem;
    newItem->next = head;
    head = newItem;
  }
  length++;
}

// Prints the list to stdout - one item per line
void LinkedList::print() {
  Node *n = head;
  for (int i = 0; i < length; i++) {
    std::cout << n->data << std::endl;
    n = n->next;
  }
}


