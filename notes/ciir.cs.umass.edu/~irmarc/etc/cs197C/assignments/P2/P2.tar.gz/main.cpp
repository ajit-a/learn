#include "LinkedList.h"
#include <iostream>

using namespace std;

int square (int x) { return (x*x); }

int main(int argc, char *argv[]) {

  LinkedList *list = new LinkedList();

  // Append some numbers
  for (int i = 0; i < 100; i++) {
    list->append(i);
  }

  // Put something on the front
  list->unshift(-9);
  
  // Size should be 101
  cout << "Size is : " << list->size() << endl;

  // Now remove 86
  int item = list->remove(87);
  cout << "Removed : " << item << endl;

  // Insert -1 in that place
  list->insert(87, -1);

  // Map all values by squaring them
  list->map(square);

  // Now print them out -- ideally this would be an iterator
  for (int i = 0; i < list->size(); i++) {
    int item = list->get(i);
    cout << "Item at " << i << " " << item << endl;
  }
  
  // Should just print the contents out
  list->print();

  // Remember this should clear all memory internally allocated.
  delete list;
}
