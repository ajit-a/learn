#include "functions.h"
#include <math.h>

// This function should print out the Pascal's Triangle, to the depth specified.
void pascals_triangle(int depth) {
  // Implement problem 2 in here.
  // Define and use any functions you like.
}

/**
 * To use the function pointer, say, for the number 5.7, and to store the value in the variable 
 * 'result' the call will look like this:
 * double result = pf(5.7);
 *
 * So, the function pointer may be used like a normal function call. See 'main.c' for details on
 * how to pass int the function to be pointed to correctly.
 */
double root(double (*pf)(double k), int a, int b, double e) {
  // Implement problem 3 here.
  return 0.0;
}

/**
 * The functions defined below are the ones to use for the root function above.
 * The second function is the derivative of the one just below. You only need the
 * second function if you plan to implement the Newton-Raphson root approximation method.
 */
double test_function(double k) {
  return (pow(k, 3) -2);
}

double test_function_derivative(double k) {
  return (3 * pow(k, 2));
}
