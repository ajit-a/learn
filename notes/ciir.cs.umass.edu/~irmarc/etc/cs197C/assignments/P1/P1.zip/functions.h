#ifndef P1_FUNCTIONS
#define P1_FUNCTIONS


void pascals_triangle(int depth);

/**
 * This function takes a function pointer. 
 */
double root(double (*pf)(double k), int a, int b, double e);
  
/**
 * The function(s) you'll be pointing to.
 */
double test_function(double k);
double test_function_derivative(double k);

#endif //P1_FUNCTIONS
