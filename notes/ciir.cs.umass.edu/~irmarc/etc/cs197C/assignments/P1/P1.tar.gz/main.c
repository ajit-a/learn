#include "functions.h"


int main(int argc, char *argv[]) {

  // Need to implement argument processing here
  
  // For Problem 1, you need to be able to handle the case when
  // argv[1] == "1", "2", or "3"

  // For Problem 2, argv[1] == "pascal"

  // For Problem 3, argv[1] == "root"

  // Note that you can't actually use argv[1] == pascal since argv is an array
  // of C-strings. You'll need to find a function to compare C-strings.
  // Such a function does exist, and as a hint, it's in the "string.h" library...

  // If you want to set a function pointer, you just take the
  // address of the function ('&' means 'take address of'):

  double (*pf)(double k); // declares the function pointer
  pf = &test_function; // sets the value of 'pf' to the address of the 'p1::test_function' function.

  // Then to call root using the function pointer 
  // double result = root(pf, a, b, e);

  return 0;
}
